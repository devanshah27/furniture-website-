function myFunction(){
    window.location.href = "register.html";

}

function validate() {
    var uname = document.getElementById('uname').value;
    var phnum = document.getElementById('phnum').value;
    var mail = document.getElementById('mail').value;
    var pass = document.getElementById('pass').value;
    var conpass = document.getElementById('conpass').value;

   
    if (uname == "" || phnum == "" || mail == "" || pass == "" || conpass == "") {
        alert("Please fill in all fields");
        return false;
    }

    if (pass != conpass) {
        alert("Passwords do not match");
        return false;
    }

    var gender = document.querySelector('input[name="gender"]:checked');
    if (!gender) {
        alert("Please select your gender");
        return false;
    }

    return true; 
    window.location.href="nikeStore.html"
}

$(document).ready(function(){
  $(".image-container img").hover(function(){
    $(this).css("transform", "translateY(-10px)"); // Slide up when hovered
  }, function(){
    $(this).css("transform", "translateY(0)"); // Slide back down when mouse leaves
});
});